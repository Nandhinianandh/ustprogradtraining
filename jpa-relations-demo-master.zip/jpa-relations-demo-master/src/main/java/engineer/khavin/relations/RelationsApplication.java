package engineer.khavin.relations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelationsApplication.class, args);
	}

}
