package engineer.khavin.relations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
