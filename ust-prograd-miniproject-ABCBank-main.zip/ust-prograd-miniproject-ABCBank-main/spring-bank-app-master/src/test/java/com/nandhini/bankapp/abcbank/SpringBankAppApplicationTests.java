package com.nandhini.bankapp.abcbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBankAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
