package com.nandhini.bankapp.abcbank.enums;


public enum Currency {

    EURO, POUND, SWEDISHKRONA
}
