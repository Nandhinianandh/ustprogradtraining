package exceptions;

public class InsufficientFundsException extends Exception{
    InsufficientFundsException() {
        super("Insufficient Funds");
    }

    public InsufficientFundsException(String message) {
        super(message);
    }
}
